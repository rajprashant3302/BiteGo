const { prisma } = require("database");

exports.getVendorNotifications = async (req, res) => {
  try {
    const { restaurantId } = req.params;

    const notifications = await prisma.notification.findMany({
      where: { RestaurantID: restaurantId },
      orderBy: { CreatedAt: "desc" },
      take: 20,
    });

    res.status(200).json({
      success: true,
      notifications,
    });
  } catch (error) {
    console.error("getVendorNotifications error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.markNotificationRead = async (req, res) => {
  try {
    const { notificationId } = req.params;

    const updated = await prisma.notification.update({
      where: { NotificationID: notificationId },
      data: { IsRead: true },
    });

    res.status(200).json({
      success: true,
      notification: updated,
    });
  } catch (error) {
    console.error("markNotificationRead error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};