const { prisma } = require("database");
const { publishEvent } = require("../kafka/producer");

exports.placeOrder = async (req, res) => {
  const { userId, items, addressId, useWallet, paymentMethod, restaurantId, couponCode } = req.body;

  try {
    const [dbItems, activeOffers, userProfile] = await Promise.all([
      prisma.menuItem.findMany({
        where: { ItemID: { in: items.map(i => i.id || i.ItemID) } }
      }),
      prisma.offer.findMany({
        where: {
          RestaurantID: restaurantId,
          IsActive: true,
          EndTime: { gte: new Date() }
        },
        include: { applicableItems: true }
      }),
      prisma.user.findUnique({ where: { UserID: userId } })
    ]);

    if (!userProfile) throw new Error("User not found");

    let subtotal = 0;
    const processedItems = items.map(cartItem => {
      const dbItem = dbItems.find(d => d.ItemID === (cartItem.id || cartItem.ItemID));
      if (!dbItem) throw new Error(`Item ${cartItem.ItemName || "selected"} no longer available`);

      const basePrice = Number(dbItem.Price);
      const itemOffer = activeOffers.find(o => o.applicableItems.some(ai => ai.MenuItemID === dbItem.ItemID));
      const storeOffer = activeOffers.find(o => o.applicableItems.length === 0);
      const bestOffer = itemOffer || storeOffer;

      let finalPrice = basePrice;
      if (bestOffer) {
        if (bestOffer.DiscountType === "Percentage") {
          let discount = basePrice * (Number(bestOffer.DiscountValue) / 100);
          if (bestOffer.MaxDiscount) discount = Math.min(discount, Number(bestOffer.MaxDiscount));
          finalPrice -= discount;
        } else {
          finalPrice -= Number(bestOffer.DiscountValue);
        }
      }

      const itemTotal = Math.max(0, finalPrice) * cartItem.quantity;
      subtotal += itemTotal;

      return {
        ItemID: dbItem.ItemID,
        Quantity: cartItem.quantity,
        ItemPrice: Math.max(0, finalPrice)
      };
    });

    const result = await prisma.$transaction(async (tx) => {
      let totalAfterCoupon = subtotal;
      let appliedCouponId = null;

      if (couponCode) {
        const coupon = await tx.coupon.findUnique({
          where: { CouponCode: couponCode, IsActive: true }
        });

        if (!coupon || (coupon.ExpiryDate && new Date(coupon.ExpiryDate) < new Date())) {
          throw new Error("Invalid or expired coupon code");
        }

        const couponDiscount = coupon.DiscountType === "Percentage"
          ? totalAfterCoupon * (Number(coupon.DiscountValue) / 100)
          : Number(coupon.DiscountValue);

        totalAfterCoupon = Math.max(0, totalAfterCoupon - couponDiscount);
        appliedCouponId = coupon.CouponID;
      }

      let walletDeduction = 0;
      if (useWallet) {
        walletDeduction = Math.min(Number(userProfile.WalletBalance), totalAfterCoupon);
        if (walletDeduction > 0) {
          await tx.user.update({
            where: { UserID: userId },
            data: { WalletBalance: { decrement: walletDeduction } }
          });

          await tx.walletTransaction.create({
            data: {
              UserID: userId,
              Amount: walletDeduction,
              TransactionType: "Debit",
              Description: "Order payment split"
            }
          });
        }
      }

      const remainingAmount = totalAfterCoupon - walletDeduction;

      const order = await tx.orders.create({
        data: {
          UserID: userId,
          RestaurantID: restaurantId,
          AddressID: addressId,
          TotalAmount: totalAfterCoupon,
          OrderStatus: "Placed",
          items: { create: processedItems },
          ...(appliedCouponId && {
            couponUsages: { create: { CouponID: appliedCouponId, UserID: userId } }
          })
        }
      });

      if (walletDeduction > 0) {
        await tx.payment.create({
          data: {
            OrderID: order.OrderID,
            UserID: userId,
            TotalAmount: walletDeduction,
            PaymentMethod: "Wallet",
            PaymentStatus: "Success"
          }
        });
      }

      let secondaryPayment = null;
      if (remainingAmount > 0) {
        secondaryPayment = await tx.payment.create({
          data: {
            OrderID: order.OrderID,
            UserID: userId,
            TotalAmount: remainingAmount,
            PaymentMethod: paymentMethod === "online" ? "UPI" : "COD",
            PaymentStatus: "Pending"
          }
        });
      }

      return { order, secondaryPayment, remainingAmount };
    }, {
      maxWait: 5000,
      timeout: 10000
    });

    if (result.remainingAmount > 0 && paymentMethod === "online") {
      await publishEvent("payment-initiated", {
        orderId: result.order.OrderID,
        amount: result.remainingAmount,
        userId: userId,
        paymentId: result.secondaryPayment.PaymentID
      });
    } else if (result.remainingAmount === 0 || paymentMethod === "cod") {
      await publishEvent("order-confirmed", {
        orderId: result.order.OrderID,
        restaurantId: restaurantId,
        userId: userId,
        addressId: addressId,
        status: "Preparing"
      });
    }

    res.status(201).json({
      success: true,
      orderId: result.order.OrderID,
      remainingAmount: result.remainingAmount,
      paymentId: result.secondaryPayment ? result.secondaryPayment.PaymentID : null
    });

  } catch (error) {
    console.error("Order Error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getOrders = async (req, res) => {
  try {
    const { userId } = req.params;

    const orders = await prisma.orders.findMany({
      where: { UserID: userId },
      include: {
        restaurant: {
          select: { Name: true, CategoryName: true }
        },
        items: {
          include: { item: { select: { ItemName: true } } }
        }
      },
      orderBy: { OrderDateTime: "desc" }
    });

    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getVendorOrders = async (req, res) => {
  try {
    const { restaurantId } = req.params;

    const orders = await prisma.orders.findMany({
      where: {
        RestaurantID: restaurantId,
        OrderStatus: {
          in: ["Placed", "Preparing", "Prepared"]
        }
      },
      include: {
        user: {
          select: {
            UserID: true,
            Name: true,
            Email: true,
            Phone: true
          }
        },
        address: true,
        payments: true,
        items: {
          include: {
            item: {
              select: {
                ItemID: true,
                ItemName: true
              }
            }
          }
        },
        restaurant: {
          select: {
            RestaurantID: true,
            Name: true
          }
        }
      },
      orderBy: { OrderDateTime: "desc" }
    });

    const formattedOrders = orders.map((order) => ({
      orderId: order.OrderID,
      status: order.OrderStatus,
      orderDateTime: order.OrderDateTime,
      totalAmount: order.TotalAmount,
      restaurantId: order.RestaurantID,
      restaurantName: order.restaurant?.Name || "",
      customer: order.user ? {
        userId: order.user.UserID,
        name: order.user.Name,
        email: order.user.Email,
        phone: order.user.Phone
      } : null,
      address: order.address ? {
        addressId: order.address.AddressID,
        addressLine: order.address.AddressLine,
        city: order.address.City,
        pincode: order.address.Pincode
      } : null,
      items: order.items.map((orderItem) => ({
        itemId: orderItem.ItemID,
        itemName: orderItem.item?.ItemName || "Unknown Item",
        quantity: orderItem.Quantity,
        price: orderItem.ItemPrice
      })),
      payments: order.payments.map((payment) => ({
        paymentId: payment.PaymentID,
        method: payment.PaymentMethod,
        status: payment.PaymentStatus,
        amount: payment.TotalAmount
      }))
    }));

    res.status(200).json({
      success: true,
      orders: formattedOrders
    });
  } catch (error) {
    console.error("getVendorOrders error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getOrderById = async (req, res) => {
  try {
    const { orderId } = req.params;

    const order = await prisma.orders.findUnique({
      where: { OrderID: orderId },
      include: {
        restaurant: true,
        items: { include: { item: true } },
        address: true,
        payments: true,
        deliveryPartner: {
          include: { user: { select: { Name: true, Phone: true, ProfilePicURL: true } } }
        }
      }
    });

    if (!order) return res.status(404).json({ message: "Order not found" });

    const statusMap = {
      Placed: 1,
      Preparing: 2,
      Prepared: 2,
      PickedUp: 3,
      Delivered: 4,
      Cancelled: 0
    };

    const tracking = {
      currentStatus: order.OrderStatus,
      step: statusMap[order.OrderStatus] || 0,
      isCancelled: order.OrderStatus === "Cancelled",
      steps: [
        { label: "Confirmed", time: order.OrderDateTime },
        { label: "Kitchen is preparing", isActive: statusMap[order.OrderStatus] >= 2 },
        { label: "Out for delivery", isActive: statusMap[order.OrderStatus] >= 3 },
        { label: "Arrived", isActive: statusMap[order.OrderStatus] >= 4 }
      ]
    };

    res.status(200).json({ ...order, tracking });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateOrderStatus = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { status } = req.body;

    const updatedOrder = await prisma.orders.update({
      where: { OrderID: orderId },
      data: { OrderStatus: status },
      include: { user: { select: { UserID: true } } }
    });

    const io = req.app.get("socketio");

    io.to(`user_${updatedOrder.UserID}`).emit("order_status_update", {
      orderId: updatedOrder.OrderID,
      status: updatedOrder.OrderStatus,
      message: `Your order is now ${updatedOrder.OrderStatus}!`
    });

    if (updatedOrder.RestaurantID) {
      io.to(`restaurant_${updatedOrder.RestaurantID}`).emit("vendor_order_status_updated", {
        orderId: updatedOrder.OrderID,
        status: updatedOrder.OrderStatus
      });
    }

    res.status(200).json({ success: true, status: updatedOrder.OrderStatus });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateVendorOrderStatus = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { status, restaurantId } = req.body;

    if (!["Preparing", "Prepared"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid vendor status"
      });
    }

    const order = await prisma.orders.findUnique({
      where: { OrderID: orderId }
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    if (restaurantId && order.RestaurantID !== restaurantId) {
      return res.status(403).json({
        success: false,
        message: "You are not allowed to update this order"
      });
    }

    const updatedOrder = await prisma.orders.update({
      where: { OrderID: orderId },
      data: { OrderStatus: status },
      include: {
        user: { select: { UserID: true, Name: true } },
        restaurant: { select: { RestaurantID: true, Name: true } }
      }
    });

    const io = req.app.get("socketio");

    io.to(`restaurant_${updatedOrder.RestaurantID}`).emit("vendor_order_status_updated", {
      orderId: updatedOrder.OrderID,
      status: updatedOrder.OrderStatus
    });

    io.to(`user_${updatedOrder.UserID}`).emit("order_status_update", {
      orderId: updatedOrder.OrderID,
      status: updatedOrder.OrderStatus,
      message: `Your order is now ${updatedOrder.OrderStatus}!`
    });

    res.status(200).json({
      success: true,
      order: updatedOrder
    });
  } catch (error) {
    console.error("updateVendorOrderStatus error:", error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
};

exports.getInvoiceData = async (req, res) => {
  try {
    const { orderId } = req.params;

    const order = await prisma.orders.findUnique({
      where: { OrderID: orderId },
      include: {
        user: true,
        restaurant: true,
        items: { include: { item: true } },
        invoice: true,
      }
    });

    if (!order) return res.status(404).json({ message: "Order not found" });

    if (order.invoice?.PDFUrl) {
      return res.status(200).json({ url: order.invoice.PDFUrl, exists: true });
    }

    res.status(200).json({ order, exists: false });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.saveInvoiceUrl = async (req, res) => {
  const { orderId, pdfUrl } = req.body;
  try {
    const invoice = await prisma.invoice.create({
      data: {
        OrderID: orderId,
        PDFUrl: pdfUrl,
      }
    });
    res.status(201).json(invoice);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};