const express = require("express");
const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const notifications = [
      {
        title: "New Order Received",
        text: "A new order has been placed.",
        type: "success",
      },
      {
        title: "Preparing Order",
        text: "An order is currently being prepared.",
        type: "time",
      },
    ];

    res.json(notifications);
  } catch (error) {
    res.status(500).json({
      message: "Failed to load notifications",
    });
  }
});

module.exports = router;